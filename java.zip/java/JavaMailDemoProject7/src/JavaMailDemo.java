import java.util.*;  
import javax.mail.*;  
import javax.mail.internet.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.activation.*;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner; // Import the Scanner class to read text files
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;


public class JavaMailDemo implements ActionListener{
	
	private static String USER_NAME = "ameyachess2019@gmail.com";  // GMail user name (just the part before "@gmail.com")
    private static String PASSWORD = "97262452220"; // GMail password
    private static String RECIPIENT = "ameyachess2005@rediffmail.com";
    JButton send ;
    JButton reset ;
    JTextField tfName;
    JTextField tfEmail;
    JTextField tfPassword;
    JFrame frame;
    public static int senderNumber = 0;
    public static int receiverNumber = 0;
     
    FileHandler fh = null;
    FileHandler handler = null;
    Logger logger = null;
    

  
    public JavaMailDemo()
    {
        try {  

            // This block configure the logger with handler and formatter 
        	handler = new FileHandler("d://default1.log", true);
        	logger = Logger.getLogger("MyLog"); 
            //logger = Logger.getLogger("com.javacodegeeks.snippets.core");
            fh = new FileHandler("D:\\ameya/java_email/MyLogFile.log");  
            logger.addHandler(fh);
            SimpleFormatter formatter = new SimpleFormatter();  
            fh.setFormatter(formatter); 
            logger.addHandler(handler);

            // the following statement is used to log any messages  
            logger.info("My first log");  

        } catch (SecurityException se) {  
            se.printStackTrace();  
        } catch (IOException ioe) {  
            ioe.printStackTrace();  
        }
    	frame = new JFrame("Chat Frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        JPanel panel = new JPanel(); 
        JLabel nameLabel = new JLabel("Enter Name");
        JLabel emailLabel = new JLabel("Enter Email");
        JLabel passwordLabel = new JLabel("Enter Password");
        tfName = new JTextField(10); // accepts upto 10 characters
        tfEmail = new JTextField(10); // accepts upto 10 characters
        //tfPassword = new JTextField(10); // accepts upto 10 characters
        tfPassword = new JPasswordField(10);
        send = new JButton("Login");
        reset = new JButton("Reset");
        panel.setLayout(new GridLayout(4,2));  
        panel.add(nameLabel); // Components Added using Flow Layout
        panel.add(tfName);
        panel.add(emailLabel);
        panel.add(tfEmail);
        panel.add(passwordLabel);
        panel.add(tfPassword);
        panel.add(send);
        panel.add(reset);
        frame.add(panel);
        
        frame.setSize(300,150);
        frame.setVisible(true);

    /*
    	Properties props = System.getProperties();
        String host = "smtp.gmail.com";
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.user", from);
        props.put("mail.smtp.password", pass);
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        */
        send.addActionListener(this);
        reset.addActionListener(this);
    }
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		JavaMailDemo j = new JavaMailDemo();
        File myObjSender = new File("sender.txt");
		File myObjReceiver = new File("receiver.txt");
    	String emailSender = "";
    	String password = "";
    	String emailReciever = "";
    	Scanner myReaderSender = new Scanner(myObjSender);
        while (myReaderSender.hasNextLine()) {
            String data = myReaderSender.nextLine();
            System.out.println(data);
            emailSender = (data.split(","))[0];
            password = (data.split(","))[1];            
			String from = emailSender;
	        String pass = password;
	        Scanner myReaderReciever = new Scanner(myObjReceiver);
	        ArrayList toList = new ArrayList();
	        while (myReaderReciever.hasNextLine()) {
	        	emailReciever = myReaderReciever.nextLine();
	        	toList.add(emailReciever); // list of recipient email addresses
		        
	        }
	        String subject = "Java send mail example";
	        String body = "Welcome to JavaMail!";

        	//sendFromGMail(from, pass, to, subject, body);
        }
        
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String name="";
		String email="";
		String password = "";
		if(e.getSource()==send)
		{
			System.out.println("Hello send");
			name = tfName.getText();
			email = tfEmail.getText();
			password = tfPassword.getText();
			if(name==null || name.trim().length()==0)
			{
				JOptionPane.showMessageDialog(frame, "Name should not be blank");
				logger.info("Name should not be blank");  
			}
			else
			if(email==null || email.trim().length()==0)
			{
				JOptionPane.showMessageDialog(frame, "Email should not be blank");
				logger.info("Email should not be blank");  
			}
			else
			if(password==null || password.trim().length()==0)
			{
				JOptionPane.showMessageDialog(frame, "Password should not be blank");
				logger.info("Password should not be blank");  
			}
			else
			{
				try {
					boolean authenticate = validAuthentication(email,password);
					if(authenticate)
					{
						sendEmail(name,email,password);
					}
					else
					{
						JOptionPane.showMessageDialog(frame, "Invalid User Name & Password");
						logger.info("Invalid User Name & Password");  
					}
				} catch (FileNotFoundException | MessagingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			senderNumber = 0;
			receiverNumber = 0;
		}
		else
		if(e.getSource()==reset)
		{
			tfName.setText("");
			tfEmail.setText("");
			tfPassword.setText("");
		}
	}
	public void sendEmail(String name, String email, String password) throws MessagingException, IOException, AddressException 
	{
		String fromEmail = email;
		String pass = password;
		ArrayList listReciever = new ArrayList();
		Properties props = System.getProperties();
        String host = "smtp.gmail.com";
        //String host = "localhost";
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.user", fromEmail);
        props.put("mail.smtp.password", password);
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");

        Session session = Session.getDefaultInstance(props);
        //MimeMessage message = new MimeMessage(session);
         
		File myObjReceiver = new File("receiver.txt");
		String emailReciever = "";
		
		Scanner myReaderReciever = new Scanner(myObjReceiver);
		while (myReaderReciever.hasNextLine()) {
            emailReciever = myReaderReciever.nextLine();
            listReciever.add(emailReciever);           
            System.out.println(emailReciever);
		}
		
	      
		Transport transport = session.getTransport("smtp");
        transport.connect(host, fromEmail, pass);
        InternetAddress[] toAddress = new InternetAddress[listReciever.size()];
        for( int i = 0; i < listReciever.size(); i++ ) {
            toAddress[i] = new InternetAddress((String)listReciever.get(i));
        }
        for( int i = 0; i < toAddress.length; i++) {
        	receiverNumber++;
        	MimeMessage message = new MimeMessage(session);
        	message.setSubject(senderNumber +" "+name+" "+receiverNumber);
            message.setText(getBodyMessage());            
            message.addRecipient(Message.RecipientType.TO, toAddress[i]);
            MimeBodyPart messageBodyPart = new MimeBodyPart();  	
            writeAttachmentFile("attachment.txt",senderNumber +" "+name+" "+receiverNumber);
    		DataSource source = new FileDataSource("attachment.txt");  
    	    messageBodyPart.setDataHandler(new DataHandler(source));  
    	    messageBodyPart.setFileName("attachment.txt"); 
    	    Multipart multipart = new MimeMultipart();
    	    multipart.addBodyPart(messageBodyPart);  
            message.setContent(multipart );
            transport.sendMessage(message, message.getAllRecipients()); 
            //transport.send(message);
        }
        //message.addRecipient(Message.RecipientType.TO , emailReciever);
   
        
		//transport.sendMessage(message, message.getAllRecipients()); 
        //transport.sendMessage(message);
        
		transport.close();
	}
	public boolean validAuthentication(String email,String password) throws FileNotFoundException
	{
		File myObjSender = new File("sender.txt");
		boolean valid = false;
    	String emailSender = "";
    	String passwordd = "";
    	
    	Scanner myReaderSender = new Scanner(myObjSender);
        while (myReaderSender.hasNextLine()) {
        	senderNumber++;
            String data = myReaderSender.nextLine();
            System.out.println(data);
            emailSender = (data.split(","))[0];
            passwordd = (data.split(","))[1];          
            if(email.trim().equalsIgnoreCase(emailSender) && password.equalsIgnoreCase(passwordd) )
            {
            	valid = true;
            	break;
            }
        }
        return valid;
	}
	public String getBodyMessage() throws IOException
	{
		File file = new File("mailBody.txt"); 
		  
		  BufferedReader br = new BufferedReader(new FileReader(file)); 
		  String wholeString = "";
		  String st; 
		  while ((st = br.readLine()) != null) 
		  {
		    System.out.println(st); 
		  	wholeString = wholeString + st + "\n"; 
		  } 
		 return wholeString;
	}
	public String getSubjectMessage() throws IOException
	{
		File file = new File("mailBody.txt"); 
		  
		  BufferedReader br = new BufferedReader(new FileReader(file)); 
		  String wholeString = "";
		  String st; 
		  while ((st = br.readLine()) != null) 
		  {
		    System.out.println(st); 
		  	wholeString = wholeString + st + "\n"; 
		  } 
		 return wholeString;
	}
	public void writeAttachmentFile(String fileName, String content)
	{
		try {
		      	File myObj = new File(fileName);
		        System.out.println("File created: " + myObj.getName());
		        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
		        writer.write(content);		        
		        writer.close();
		      
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}
}


